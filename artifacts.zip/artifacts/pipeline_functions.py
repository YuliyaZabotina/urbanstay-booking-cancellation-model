# Функции для подготовки данных к моделированию
# UrbanStay Booking Cancellation Prediction

import pandas as pd
import numpy as np
import re

def load_and_merge_data(engine):
    # Загружаем таблицы
    df_bookings = pd.read_sql_query("SELECT * FROM hotel_bookings;", con=engine)
    df_reviews = pd.read_sql_query("SELECT * FROM hotel_reviews;", con=engine)
    
    # Приводим даты к datetime
    df_bookings["booking_date"] = pd.to_datetime(df_bookings["booking_date"], errors="coerce")
    df_reviews["review_date"] = pd.to_datetime(df_reviews["review_date"], errors="coerce")
    
    # Удаляем полные дубликаты из бронирований
    df_bookings = df_bookings.drop_duplicates(keep="first").reset_index(drop=True)
    
    # Удаляем дубликаты отзывов по booking_id (оставляем самый поздний)
    df_reviews = (
        df_reviews.sort_values(["booking_id", "review_date"])
        .drop_duplicates(subset=["booking_id"], keep="last")
        .reset_index(drop=True)
    )
    
    # Исправляем опечатку в meal_plan
    df_bookings["meal_plan"] = df_bookings["meal_plan"].replace({"не выбрант": "не выбран"})
    
    # Добавляем customer_id в таблицу бронирований
    customer_id_map = df_reviews[["booking_id", "customer_id"]].copy()
    df_bookings_ext = df_bookings.merge(customer_id_map, on="booking_id", how="left")
    
    # Делим на известные и неизвестные customer_id
    bookings_known = df_bookings_ext[df_bookings_ext["customer_id"].notna()].copy()
    bookings_unknown = df_bookings_ext[df_bookings_ext["customer_id"].isna()].copy()
    
    # Сортируем для merge_asof
    bookings_sorted = bookings_known.sort_values(["booking_date", "customer_id"]).reset_index(drop=True)
    reviews_sorted = df_reviews.sort_values(["review_date", "customer_id"]).reset_index(drop=True)
    
    # Объединяем по правилу: ближайший предыдущий отзыв
    df_known = pd.merge_asof(
        bookings_sorted,
        reviews_sorted[["customer_id", "review_date", "stay_rating", "review_text"]],
        left_on="booking_date",
        right_on="review_date",
        by="customer_id",
        direction="backward",
        allow_exact_matches=False,
    )
    
    # Возвращаем строки без customer_id
    bookings_unknown["review_date"] = pd.NaT
    bookings_unknown["stay_rating"] = np.nan
    bookings_unknown["review_text"] = ""
    
    df = pd.concat([df_known, bookings_unknown], ignore_index=True)
    df["review_text"] = df["review_text"].fillna("")
    
    return df


def clean_data(df):
    df = df.copy()
    
    # Удаляем строки с нулевой стоимостью бронирования
    zero_mask = df["booking_value"].eq(0)
    df = df[~zero_mask].reset_index(drop=True)
    
    # Исправляем аномальные значения adult_count
    anomal_mask = df["adult_count"].isin([100, 200, 300])
    correction_map = {100: 1, 200: 2, 300: 3}
    df.loc[anomal_mask, "adult_count"] = (
        df.loc[anomal_mask, "adult_count"].map(correction_map).astype(int)
    )
    
    return df


def create_features(df):
    df = df.copy()
    
    # Общая длительность проживания
    df["total_nights"] = df["weekday_nights"] + df["weekend_nights"]
    
    # Доля отмен в истории клиента
    prev_total_bookings = df["previous_cancellations"] + df["previous_no_shows"]
    df["previous_cancel_rate"] = df["previous_cancellations"] / (prev_total_bookings + 1)
    
    # Сезон по планируемой дате заезда
    checkin_date = df["booking_date"] + pd.to_timedelta(df["days_until_checkin"], unit="D")
    month_checkin = checkin_date.dt.month
    
    df["season"] = np.select(
        [
            month_checkin.isin([12, 1, 2]),
            month_checkin.isin([3, 4, 5]),
            month_checkin.isin([6, 7, 8]),
            month_checkin.isin([9, 10, 11]),
        ],
        ["зима", "весна", "лето", "осень"],
        default="неизвестно"
    )
    
    # Удаляем исходные признаки, которые агрегировали
    cols_to_drop = [
        "weekday_nights",
        "weekend_nights",
        "previous_cancellations",
        "previous_no_shows",
        "booking_date",
    ]
    df = df.drop(columns=cols_to_drop, errors="ignore")
    
    return df


def prepare_for_model(df, is_train=True):
    df = df.copy()
    
    # Текстовые признаки
    df["review_text"] = df["review_text"].fillna("").apply(
        lambda s: re.sub(r"\s+", " ", str(s).replace("\n", " ").replace("\r", " ").replace("\t", " ")).strip().lower()
    )
    df["has_review"] = (df["review_text"].str.len() > 0).astype(int)
    
    # Приводим булевы признаки к 0/1
    bool_cols = df.select_dtypes(include=["bool"]).columns.tolist()
    for c in bool_cols:
        df[c] = df[c].astype(int)
    
    if is_train:
        # Целевая переменная
        df["target"] = (df["booking_status"] == "отказ_брони").astype(int)
        
        # Group_id для разделения выборок
        df["group_id"] = df["customer_id"].fillna("no_cust_" + df["booking_id"].astype(str))
        
        # Исключаем служебные признаки
        DROP_COLS = [
            "booking_id", "customer_id", "group_id", "booking_status",
            "review_date", "target"
        ]
        y = df["target"].values
        X = df.drop(columns=[c for c in DROP_COLS if c in df.columns], errors="ignore")
        X["review_text"] = X["review_text"].fillna("").astype(str)
        
        return X, y
    else:
        # Для продакшена (без target)
        DROP_COLS = [
            "booking_id", "customer_id", "booking_status", "review_date"
        ]
        X = df.drop(columns=[c for c in DROP_COLS if c in df.columns], errors="ignore")
        X["review_text"] = X["review_text"].fillna("").astype(str)
        
        return X


